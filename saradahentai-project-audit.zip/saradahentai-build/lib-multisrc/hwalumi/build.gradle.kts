plugins {
    alias(kei.plugins.multisrc)
}

keiyoushi {
    baseVersionCode = 3
    libVersion = "1.6"

    deeplink {
        path("/comic/..*")
        path("/komik/..*")
    }
}
